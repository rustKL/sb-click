#another rewrite
#https://developer.spotify.com/dashboard
#https://console.cloud.google.com/apis/api/youtube.googleapis.com/credentials --this is for google api services
#this is my selfbot v2
#requested alot so i made it using discord py self
#older version was in usercord
#might upgrade with new usercord module
#alot of changes were made, better error handling too!
#voice updates in the future
#please refer to the comments and read them carefully, also checkout the links on the top
#add your own api keys on the caps below
#install the modules below using pip
#most variables are written_Like_this to make it easier for you to read
#make sure to execute multibots.py for the multi-token kit
#install discordpy self from:  https://github.com/dolfies/discord.py-self,
#use this command to install it, py -3 -m pip install -U discord.py-self[voice] or python3 -m pip install -U "discord.py-self[voice]"
#made by zen_xf
from __future__ import annotations
from googletrans import Translator
import yt_dlp as youtube_dl
import discord
from discord.ext import commands
import datetime
import asyncio
from random import randint
from datetime import datetime
from pypresence import Presence
from appembed import Appembed
import aiohttp
from dhooks import Webhook, Embed
import instaloader
import os
from colorama import Fore, Style, init
from pystyle import System
import json
import requests
import platform
from googleapiclient.discovery import build
import threading
import urllib.parse
import subprocess
import pyfiglet
from discord import FFmpegPCMAudio
import spotipy
import string
from pystyle import Write, Colors
from datetime import timedelta
import random
import time
import socket
from discord.utils import utcnow
import warnings
from spotipy.oauth2 import SpotifyClientCredentials
from pydub import AudioSegment
from pydub.playback import play as pydub_play

translator = Translator()


with warnings.catch_warnings():
    warnings.simplefilter("ignore", category=DeprecationWarning)
    bst = datetime.utcnow()
print(bst)

#api bs
API_BASE = "https://discord.com/api/v9"
AUTH_FAIL = "Auth failed"
PROXY_FAIL = "Proxy failed"

#api keys here
GOOGLE_API_KEY = 'AIzaSyARe4G7gL0aLOEAmjCZpLcFPZeNUQLKwds' #https://console.cloud.google.com/apis/credentials
SEARCH_ENGINE_ID = '243b37799d6de48fe' # get from https://programmablesearchengine.google.com/, make search engine(add then get id)
YOUTUBE_API_KEY = 'AIzaSyD-12mEt8kYHXU4WvH3zVq0dtJGKp8_JvE' #get from https://console.cloud.google.com/marketplace/product/google/youtube.googleapis.com
SPOTIFY_CLIENT_ID = '05e36a72788a421198550a5d4f21037e' #get from https://developer.spotify.com/dashboard (make an app in the dashboard)
SPOTIFY_CLIENT_SECRET = 'dc95b31570814becbacb04f0470a57f8' #get from https://developer.spotify.com/dashboard
ROBLOX_USER_API = "https://users.roblox.com/v1/users/search?keyword={}"
ROBLOX_PROFILE_API = "https://users.roblox.com/v1/users/{}"
ROBLOX_FOLLOWERS_API = "https://friends.roblox.com/v1/users/{}/followers/count"
ROBLOX_FOLLOWING_API = "https://friends.roblox.com/v1/users/{}/followings/count"




def gf(client, message):
    df = ">"
    if os.path.exists('prefix.json'):
        try:
            with open('prefix.json', 'r') as f:
                if os.stat('prefix.json').st_size == 0:
                    return df
                prefixes = json.load(f)
            if message.guild:
                return prefixes.get(str(message.guild.id), df)
            else:
                return prefixes.get(str(message.author.id), df)
        except (json.JSONDecodeError, KeyError):
            return df
    return df

bot = commands.Bot(command_prefix=gf, self_bot=True)

@bot.command()
async def setprefix(ctx, new_prefix):
    if os.path.exists('prefix.json'):
        try:
            with open('prefix.json', 'r') as f:
                if os.stat('prefix.json').st_size == 0:
                    prefixes = {}
                else:
                    prefixes = json.load(f)
        except json.JSONDecodeError:
            prefixes = {}
    else:
        prefixes = {}
    if ctx.guild:
        prefixes[str(ctx.guild.id)] = new_prefix
    else:
        prefixes[str(ctx.author.id)] = new_prefix
    with open('prefix.json', 'w') as f:
        json.dump(prefixes, f)

    await ctx.send(f'```prefix changed to: {new_prefix}```')


def setrpc():
    client_id = Write.Input("enter your client id: ", Colors.blue_to_purple, interval=0.0025)
    RPC = Presence(client_id)
    RPC.connect()

    def get_input(prompt):
        value = input(prompt)
        return value if value else None

    pt = {
        "state": get_input("Enter user’s current status (state): "),
        "details": get_input("Enter what the player is currently doing (details): "),
        "start": int(get_input("Enter epoch time for game start (start): ") or 0),
        "end": int(get_input("Enter epoch time for game end (end): ") or 0),
        "large_image": get_input("Enter name of the uploaded image for the large profile artwork (large_image): "),
        "large_text": get_input("Enter tooltip for the large image (large_text): "),
        "small_image": get_input("Enter name of the uploaded image for the small profile artwork (small_image): "),
        "small_text": get_input("Enter tooltip for the small image (small_text): ")
        #"buttons": eval(get_input("Enter list of dicts for buttons on your profile in format [{\"label\": \"My Website\", \"url\": \"https://qtqt.cf\"}, ...] (buttons): ") or '[]')
    }

    pt = {k: v for k, v in pt.items() if v is not None}

    RPC.update(**pt)
    print("custom presence set!")

def lp():
    client_id = Write.Input("enter your client id: ", Colors.blue_to_purple, interval=0.0025)
    RPC = Presence(client_id)
    RPC.connect()

    quotes = []
    while True:
        quote = input("enter a quote (or press enter to finish): ")
        if not quote:
            break
        quotes.append(quote)
    print("starting..")
    try:
        while True:
            quote = random.choice(quotes)
            RPC.update(details="so:", state=quote)
            time.sleep(3)
    except KeyboardInterrupt:
        print("quote loop stopped..")

def setconfig():
    print("idk")




System.Title("cerium")

init(autoreset=True)



asciiart = f"""

░█████╗░███████╗██████╗░██╗██╗░░░██╗███╗░░░███╗
██╔══██╗██╔════╝██╔══██╗██║██║░░░██║████╗░████║
██║░░╚═╝█████╗░░██████╔╝██║██║░░░██║██╔████╔██║
██║░░██╗██╔══╝░░██╔══██╗██║██║░░░██║██║╚██╔╝██║
╚█████╔╝███████╗██║░░██║██║╚██████╔╝██║░╚═╝░██║
░╚════╝░╚══════╝╚═╝░░╚═╝╚═╝░╚═════╝░╚═╝░░░░░╚═╝

[+] made by zen_xf

[+] new updates: call/multiple accounts botting in multibots.py file

[+] if errors occur send the debug logs from your cmd

[+] enjoy!

"""



tkn = input("enter token: ")


def prt(text, delay=0.03):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

print(asciiart)
def mn():
    while True:
        print("\nmain menu: ")
        print("1. Main")
        print("2. config")
        print("3. loop quote presence")
        print("4. exit")

        option = input("please select one of options 1-3: ")

        if option == '1':
            setrpc()
        elif option == '2':
            function2()
        elif option == '3':
            lp()
        elif option == '4':
            print("exiting the menu ..")
            break
        else:
            print("invalid choice, please try again")




#embed
@bot.command()
async def helpx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=credits%20to%20%40zen%20%23%0A%3E%20user%20%2F%20user%20commands%0A%3E%20util%20%2F%20util%20commands%0A%3E%20unix%20%2F%20unix%20commands%0A%3E%20guild%20%2F%20guild%20commands%0A%3E%20web%20%2F%20web%20commands%0A%3E%20voice%20%2F%20voice%20commands%0A%3E%20roblox%20%2F%20roblox%20commands&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D4617'
    message = await ctx.send(f'{str}\n{embed}')


@bot.command()
async def userx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20viewpfp%0A-%20viewbanner%0A-%20userinfo%0A-%20userinfo2%0A-%20stream%0A-%20dog%0A-%20cat%0A-%20about&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def utilx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20afk%0A-%20cembed%0A-%20genuser%0A-%20ghostping%0A-%20mtping%0A-%20invite%0A-%20purge%0A-%20massreact%0A-%20poll%0A-%20startautoreaction%0A-%20autoreactionstop%0A-%20slap%0A-%20cryto%0A-%20sethypesquad%0A-%20mesh%0A-%20mesh2%0A-%20clientlightmode%0A-%20clientdarkmode%0A-%20getmessages%0A-%20ascii%0A-%20streamingw%0A-%20stopactivity%0A-%20translateglobal%0A-%20trans2english%0A-%20gettokendetails%0A-%20fakeurl%0A-%20domain2ip%0A&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def unixx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20portscan%0A-%20system%0A-%20nmap%0A-%20ping%0A-%20curl%0A-%20runfile&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def guildx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20mspurge%0A-%20nuke%0A-%20kill%0A-%20wspareraid%0A-%20abuseraid%0A-%20smessage%0A-%20wraid%0A-%20nukeh%0A-%20ban_all%0A-%20kick_all%0A-%20mute_all%0A-%20tempnuke%0A-%20threadspam%0A-%20pinspam%0A-%20adminto%0A-%20nicknameall%0A-%20serverinfo%0A-%20makechannels%0A-%20emojispam%0A-%20massmention%0A-%20categoryspam%0A-%20flood%0A-%20floodh&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def webx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20google%0A-%20igreels%0A-%20yt%0A-%20spotify&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def voicex(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20join%0A-%20leave%0A-%20play%0A-%20play2%0A-%20stop%0A-%20playwin&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def robloxx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=-%20roblox%0A-%20robloxclothing%0A-%20robloxasset&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
    message = await ctx.send(f'{str}\n{embed}')

@bot.command()
async def sysx(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    app = Appembed()
    embed = 'https://appembed.netlify.app/e?description=sys%20commands%0A%0A-%20build&color=%23737373&author=cerium&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Frhjecu-k1SaS7ITlgyAWLi3bEWapKRol2SVwz9zJik4%2F%253Fformat%253Dwebp%2526quality%253Dlossless%2526width%253D477%2526height%253D477%2Fhttps%2Fimages-ext-1.discordapp.net%2Fexternal%2F3nU7-3KrwtUSKPxHAVH8daiqFdxGBWZIn7G8QULTfsA%2F%25253Fformat%25253Dwebp%252526quality%25253Dlossless%252526width%25253D477%252526height%25253D477%2Fhttps%2Fimages-ext-1.discordapp.net%2Fexternal%2FraqI5p0OstGWU2LL6zF3a1Ees3U6HxCHTRC7T_I6EOY%2Fhttps%2Ffiles.shapes.inc%2F286d55eb.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D477%26height%3D477'
    message = await ctx.send(f'{str}\n{embed}')








@bot.command()
async def helpf(ctx, category=None):
    bt = bot.user if bot.user else "Unknown#0000"
    if not category:
        message = (
            f"> # [xnreu]\n"
            f"> \n"
            f"> Logged in as **`{bt}`**\n"
            f"> *Type <prefix>help <extension_name> to view commands relating to a specific extension. Then type <prefix>help <cmd_name> to view information regarding a command.*\n"
            f"> \n"
            f"> ## Category 1\n"
            f"> **`help`**   *Loads help menu*\n"
            f"> **`usr`**   *User commands*\n"
            f"> **`util`**   *Utility related commands*\n"
            f"> \n"
            f"> ## Category 2\n"
            f"> **`unix`**   *Linux/Unix based commands (some Windows support)*\n"
            f"> **`guild`**   *Server/DM commands*\n"
            f"> \n"
            f"> ## Category 3\n"
            f"> **`web`**   *Web based commands*\n"
            f"> **`voice`**   *Voice channel commands*\n"
            f"> \n"
            f"> ## Category 4\n"
            f"> **`roblox`**   *Roblox commands*\n"
        )
        await ctx.send(message)
        return

    commands = {
        'usr': [
            "> **`viewpfp`**   *Views a user's profile picture*",
            "> **`viewbanner`**   *Views a user's banner*",
            "> **`userinfo2`**   *Displays extended user information*",
            "> **`userinfo`**   *Displays user information*",
            "> **`stream`**   *Starts a stream*",
            "> **`dog`**   *Sends a random dog picture*",
            "> **`cat`**   *Sends a random cat picture*",
            "> **`about`**   *Sends about bot embed*",
        ],
        'util': [
            "> **`afk`**   *Sets an AFK message*",
            "> **`cembed`**   *Creates an embedded message*",
            "> **`genuser`**   *Generates a random user*",
            "> **`ghostping`**   *Sends a ghost ping*",
            "> **`mtping`**   *Sends a multi-target ping*",
            "> **`invite`**   *Sends an invite link to the server*",
            "> **`purge`**   *Deletes messages*",
            "> **`massreact`**   *Reacts with emojis en masse*",
            "> **`poll`**   *Creates a poll*",
            "> **`startautoreaction`**   *Starts an auto-reaction*",
            "> **`autoreactionstop`**   *Stops an auto-reaction*",
            "> **`slap`**   *Sends a slap action*",
            "> **`cryto`**   *Sends a cry action*",
            "> **`sethypesquad`**   *Sets the Hypesquad house*",
            "> **`mesh`**   *Performs the mesh action*",
            "> **`mesh2`**   *Performs the mesh2 action*",
            "> **`clientlightmode`**   *Sets client to light mode*",
            "> **`clientdarkmode`**   *Sets client to dark mode*",
            "> **`getmessages`**   *Fetches messages*",
            "> **`ascii`**   *Converts text to ASCII art*",
            "> **`streamingw`**   *Sets status to streaming*",
            "> **`stopactivity`**   *Stops current activity*",
            "> **`translateglobal`**   *Translates text to a specified language*",
            "> **`trans2english`**   *Translates text to English*",
            "> **`gettokendetails`**   *Fetches details of a token*",
            "> **`fakeurl`**   *Sends a fake URL*",
            "> **`domain2ip`**   *Converts domain to IP address*",
        ],
        'unix': [
            "> **`portscan`**   *Scans for open ports*",
            "> **`system`**   *Displays system information*",
            "> **`nmap`**   *Performs a network map scan*",
            "> **`ping`**   *Pings a target*",
            "> **`curl`**   *Performs a curl request*",
            "> **`runfile`**   *Runs a file*",
        ],
        'guild': [
            "> **`mspurge`**   *Mass purges messages*",
            "> **`nuke`**   *Nukes a channel*",
            "> **`kill`**   *Kills the bot*",
            "> **`wspareraid`**   *Starts a ws pare raid*",
            "> **`abuseraid`**   *Starts an abuse raid*",
            "> **`smessage`**   *Sends a secret message*",
            "> **`wraid`**   *Starts a w raid*",
            "> **`nukeh`**   *Nukes a server*",
            "> **`ban_all`**   *Bans all users*",
            "> **`kick_all`**   *Kicks all users*",
            "> **`mute_all`**   *Mutes all users*",
            "> **`tempnuke`**   *Temporarily nukes a server*",
            "> **`threadspam`**   *Spams threads*",
            "> **`pinspam`**   *Spams pins*",
            "> **`flood`**   *Floods with a message*",
            "> **`floodh`**   *Floods with a file*",
            "> **`nicknameall`**   *Changes nicknames for all members*",
            "> **`serverinfo`**   *Displays server information*",
            "> **`makechannels`**   *Creates multiple channels*",
            "> **`emojispam`**   *Spams emojis*",
            "> **`massmention`**   *Mentions multiple members*",
            "> **`categoryspam`**   *Spams categories*",
        ],
        'web': [
            "> **`google`**   *Performs a Google search*",
            "> **`igreels`**   *Fetches Instagram reels*",
            "> **`yt`**   *Fetches YouTube videos*",
            "> **`spotify`**   *Fetches Spotify tracks*",
        ],
        'roblox': [
            "> **`roblox`**   *Performs a Roblox search*",
            "> **`robloxclothing`**   *Searches for Roblox clothing*",
            "> **`robloxasset`**   *Searches for Roblox assets by ID or group*",
        ],
        'voice': [
            "> **`join`**   *Joins a voice channel*",
            "> **`leave`**   *Leaves a voice channel*",
            "> **`play`**   *Plays audio*",
            "> **`play2`**   *Plays a second audio*",
            "> **`stop`**   *Stops the audio*",
            "> **`playwin`**   *alternatives for windows users if play doesnt work*",
        ]
    }

    category = category.lower()
    if category in commands:
        message = f"> # [xnreu]\n> \n> Logged in as **`{bt}`**\n> *Type <prefix>help <extension_name> to view commands relating to a specific extension. Then type <prefix>help <cmd_name> to view information regarding a command.*\n> \n"
        message += f"> ## Category {list(commands.keys()).index(category) + 1}\n"
        message += "\n".join(commands[category])
        await ctx.send(message)
    else:
        await ctx.send("> Invalid category. Available categories: usr, util, unix, guild, web, roblox, sys, voice")


# user commands

@bot.command()
async def viewpfp(ctx, user_id: str):
    user = await bot.fetch_user(user_id)   
    av = user.avatar.url if user.avatar else user.default_avatar.url
    if not av:
        await ctx.send(f"cant fetch avatar for: {user.name}")
        return
    await ctx.send(f"{user.name}'s profile picture: {av}")

@bot.command()  # banner doesn't have embed support
async def viewbanner(ctx, user_id: str):
    user = await bot.fetch_user(user_id)
    if user.banner:
        bn = user.banner.url
        await ctx.send(f"{user.name}'s banner: {bn}")
    else:
        await ctx.send(f"{user.name} does not have a banner.")

@bot.command()
async def userinfo(ctx, *, user: discord.User):
    with open('notes.txt', 'r') as f:
        str = f.read()
    usr = user.name
    usid = user.id
    createdat = user.created_at.strftime("%Y-%m-%d %H:%M:%S")

    app = Appembed()
    message = app.set_title(f"username: {usr}") \
                .set_description(f"user id: {usid}\ncreated at: {createdat}") \
                .build()

    await ctx.send(f'{str}\n{message}')

@bot.command()
async def memberlist(ctx, guild_id: int):
    try:
        gd = bot.get_guild(guild_id)        
        if gd is None:
            await ctx.send(f"could not find members in {guild_id}.")
            return
        meb = [member.name for member in guild.members]
        await ctx.send(f"members in {guild.name}:\n" + "\n".join(meb))    
    except Exception as e:
        await ctx.send(f"an error occurred: {e}")

@bot.command()
async def userinfo2(ctx, user_id: int):
    with open('notes.txt', 'r') as f:
        str = f.read()
    member = await ctx.guild.fetch_member(user_id)
    if member:
        embed = Appembed()
        embed.set_title(f"user info: {member.name}")
        roles = [role.name for role in member.roles[1:]]
        nickname = member.nick
        premium_since = str(member.premium_since) if member.premium_since else "None"
        embed.set_description(f"user id: {user_id}\njoined: {member.joined_at.strftime('%Y-%m-%d %H:%M:%S')}\nRoles: {', '.join(roles)}\nNickname: {nickname}\nPremium: {premium_since}")
        embed_url = embed.build()
        await ctx.send(f'{str}\n{embed_url}')
    else:
        await ctx.send("user not found or not a member of this guild.")

@bot.command()
async def stream(ctx, str_n: str, stream_url: str):
    await bot.change_presence(activity=discord.Streaming(name=str_n, url=stream_url))
    await ctx.send(f"```bot status set to streaming: {str_n}```")


da = 'https://dog.ceo/api/breeds/image/random'
ca = 'https://api.thecatapi.com/v1/images/search'

@bot.command()
async def dog(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    response = requests.get(da)
    data = response.json()
    img = data['message']

    bs = "https://appembed.netlify.app/e?"
    color = "%23737373"
    author = "cerium"
    embed_url = bs + urllib.parse.urlencode({
        "color": color,
        "author": author,
        "image": img
    })

    await ctx.send(f'{str}\n{embed_url}')

@bot.command()
async def cat(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    async with aiohttp.ClientSession() as session:
        async with session.get(ca) as resp:
            json_data = await resp.json()
            img = json_data[0]['url']

            bs = "https://appembed.netlify.app/e?"
            color = "%23737373"
            author = "cerium"
            embed_url = bs + urllib.parse.urlencode({
                "color": color,
                "author": author,
                "image": img
            })

            await ctx.send(f'{str}\n{embed_url}')
# util




@bot.command()
async def cembed(ctx, *, message):
    with open('notes.txt', 'r') as f:
        note = f.read()
    try:
        embed_url = Appembed().set_title("-") \
                              .set_description(message) \
                              .build()
        await ctx.send(f'{note}\n{embed_url}')
    except Exception as e:
        await ctx.send(f"Error: {e}")

def gh():
    parts = [
        random.choice('abcdefghijklmnopqrstuvwxyz0123456789'),
        random.choice('_-'),
        random.choice('abcdefghijklmnopqrstuvwxyz0123456789'),
        random.choice('abcdefghijklmnopqrstuvwxyz')
    ]
    return ''.join(parts)

@bot.command()
async def genuser(ctx):
    usernames = [gh() for _ in range(10)]
    await ctx.send('\n'.join(usernames))


afkst = {}

@bot.command()
async def afk(ctx):
    with open('notes.txt', 'r') as f:
        note = f.read()
    afkst[ctx.author.id] = True
    
    afkt = time.time()  # Get current time in seconds
    
    app = Appembed()
    embed = app.set_title("User is AFK") \
                .set_description(f"{ctx.author.name} is now AFK") \
                .set_color("#737373") \
                .build()
    await ctx.send(f'{note}\n{embed}')

    def check(message):
        return message.author == ctx.author and "afk-notify" not in message.content

    try:
        msg = await bot.wait_for('message', check=check, timeout=300)
    except asyncio.TimeoutError:
        pass  # Will continue after timeout

    endt = time.time()  # Get current time in seconds
    elapsed_time = endt - afkt  # Calculate elapsed time

    app = Appembed()
    embed = app.set_title("Welcome back!") \
                .set_description(f"Welcome back! You were AFK for {elapsed_time:.2f} seconds.") \
                .set_color("#737373") \
                .build()
    
    await ctx.send(f'{note}\n{embed}')
    afkst.pop(ctx.author.id, None)

@bot.command()
async def ghostping(ctx, times: int = 1):
    guild = ctx.guild 
    if guild is None:
        await ctx.send("this command works only in servers")
        return

    if times < 1 or times > 10: #can modify here
        await ctx.send("specify(limit is 10)") #also this shit works if you have mod perms, if not then u get basic ping
        return

    members = guild.members
    membermentions = [member.mention for member in members if not member.bot]
    #split mentions since theres limit
    chz= 100  
    chunks = [membermentions[i:i + chz] for i in range(0, len(membermentions), chz)]

    for _ in range(times):
        messages = []
        for chunk in chunks:
            try:
                message = await ctx.send(' '.join(chunk))
                messages.append(message)
            except discord.HTTPException:
                await ctx.send("error: http exception occured")
        await asyncio.sleep(0) # can change here if theres rate limit, put 1-4
        for message in messages:
            try:
                await message.delete()
            except discord.HTTPException:
                pass 

@bot.command()
async def mtping(ctx, times: int = 1):
    if isinstance(ctx.channel, discord.DMChannel) or isinstance(ctx.channel, discord.GroupChannel):
        if times < 1 or times > 10:
            await ctx.send("```only 10 is the limit```")
            return
        if isinstance(ctx.channel, discord.DMChannel): # discordm
            members = [ctx.channel.recipient]
        elif isinstance(ctx.channel, discord.GroupChannel):#discorgroup
            members = ctx.channel.recipients

        mb = [member.mention for member in members if not member.bot]

        for _ in range(times):#basic for loop lmao
            try:
                message = await ctx.send(' '.join(mb))
                await asyncio.sleep(0)#you can change delay ig
                await message.delete()
            except discord.HTTPException:
                await ctx.send("```404```")
    else:
        await ctx.send("```works in dm or group channel```")# i will cum on you


@bot.command()
async def invite(ctx):
    msg = "https://discord.gg/hauntings" # edit here(your vanity)

    for x in range(10):
        await ctx.send(msg)

@bot.command()
async def purge(ctx, amount: int):
    if amount < 1:
        await ctx.send("specify num greater than 0")
        return
# if instance dm/ or guild
    if isinstance(ctx.channel, discord.DMChannel) or isinstance(ctx.channel, discord.GroupChannel):
        async for message in ctx.channel.history(limit=amount + 1):
            try:
                await message.delete()
            except discord.HTTPException as e:
                await ctx.send(f"Error: {e}")
                return
    elif isinstance(ctx.channel, discord.TextChannel):
        if not ctx.author.guild_permissions.manage_messages:
            await ctx.send("got no permissions(skill issue).")
            return
        try:
            deleted = await ctx.channel.purge(limit=amount + 1)  
            await ctx.send(f"deleted {len(deleted) - 1} messages", delete_after=5)
        except discord.HTTPException as e:
            await ctx.send(f"Error: {e}")


#unix

async def scn(ip, port):
    try:
        conn = asyncio.open_connection(ip, port)
        reader, writer = await asyncio.wait_for(conn, timeout=1.0)
        writer.close()
        await writer.wait_closed()
        return port, True
    except:
        return port, False

@bot.command()
async def portscan(ctx, ip: str):
    openp = []
    tasks = [scn(ip, port) for port in range(1, 1025)]
    results = await asyncio.gather(*tasks)
    for port, is_open in results:
        if is_open:
            openp.append(port)
    if openp:
        await ctx.send(f"```open ports on {ip}```: {', '.join(map(str, open_ports))}")
    else:
        await ctx.send(f"```no open ports found on {ip} in the range 1-1024```")
async def runcmd(command):
    process = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    return stdout.decode(), stderr.decode()

@bot.command()
async def system(ctx, *, cmd: str):
    stdout, stderr = await runcmd(cmd)
    output = stdout + stderr
    if len(output) > 2000:
        for i in range(0, len(output), 2000):
            await ctx.send(f"```{output[i:i+2000]}```")
    else:
        await ctx.send(f"```{output}```")

@bot.command()
async def ping(ctx, addr: str):
    cmd = f"ping -c 3 {addr}"  
    stdout, stderr = await runcmd(cmd)
    if stdout:
        await sh(ctx, stdout, "STDOUT")
    if stderr:
        await sh(ctx, stderr, "STDERR")

@bot.command()
async def nmap(ctx, *, msg: str):
    cmd = f"nmap --privileged {msg}"
    stdout, stderr = await runcmd(cmd)
    if stdout:
        await sh(ctx, stdout, "STDOUT")
    if stderr:
        await sh(ctx, stderr, "STDERR")

@bot.command()
async def curl(ctx, *, msg: str):
    cmd = f"curl {msg}"
    stdout, stderr = await runcmd(cmd)

    if stdout:
        await sh(ctx, stdout, "STDOUT")
    if stderr:
        await sh(ctx, stderr, "STDERR")

async def sh(ctx, output, output_type):
    if len(output) < 1800:
        await ctx.reply(f"```ini\n[ {output_type} ]\n{output}```", delete_after=60)
    else:
        for i in range(0, len(output), 1800):
            await ctx.reply(f"```ini\n[ {output_type} ]\n{output[i:i+1800]}```", delete_after=60)
            await asyncio.sleep(1.5)

#guild cmds

@bot.command()
async def mspurge(ctx, limit: int):
    with open('notes.txt', 'r') as f:
        note = f.read()
    
    try:
        deleted = []
        async for msg in ctx.channel.history(limit=limit):
            if msg.author == bot.user:
                await msg.delete()
                deleted.append(msg)
        
        embed_url = Appembed().set_title("Message Purge") \
                              .set_description(f"Deleted {len(deleted)} messages in {ctx.channel.name}.") \
                              .build()
        await ctx.send(f'{note}\n{embed_url}', delete_after=5)
    except discord.Forbidden:
        await ctx.send("Error: Forbidden (No permission)")
    except discord.HTTPException as e:
        await ctx.send(f"Error: HTTPException: {e}")

@bot.command()
async def nuke(ctx):
    try:
        if ctx.author.guild_permissions.manage_channels:
            for channel in ctx.guild.channels:
                await channel.delete()
            for role in ctx.guild.roles:
                try:
                    await role.delete()
                except discord.HTTPException as e:
                    print(f"error: failed to delete {role.name}: {e}")

            for member in ctx.guild.members:
                try:
                    await member.ban(reason="Server nuked")
                except discord.Forbidden:
                    print(f"error: failed to ban member {member.display_name}: missing perms")
                except discord.HTTPException as e:
                    print(f"error: {member.display_name}: {e}")

            await ctx.guild.edit(name="deleted")

            await ctx.send("server nuked")
        
        else:
            await ctx.send("error: no perms")

    except discord.Forbidden:
        await ctx.send("error: no perms")

    except discord.HTTPException as e:
        await ctx.send(f"an error occurred: {e}")


async def create_thread(channel_id: int, name: str, token: str):
    headers = {
        'Authorization': token,
        'Content-Type': 'application/json'
    }

    payload = {
        'name': name,
        'auto_archive_duration': 60,
        'type': 11 #public thread
    }

    response = requests.post(f'https://discord.com/api/v9/channels/{channel_id}/threads', headers=headers, json=payload)
    if response.status_code == 201:
        return True
    else:
        return False

@bot.command()
async def kill(ctx):
    try:
        guild = ctx.guild
        if ctx.author.guild_permissions.manage_channels:
            delete_tasks = [channel.delete() for channel in guild.channels]
            await asyncio.gather(*delete_tasks)
            create_text_tasks = []
            for i in range(1, 16):
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(read_messages=False),
                    guild.me: discord.PermissionOverwrite(read_messages=True)
                }
                create_text_tasks.append(guild.create_text_channel(f"Text Channel {i}", overwrites=overwrites))
            await asyncio.gather(*create_text_tasks)
            create_voice_tasks = [guild.create_voice_channel(f"Voice Channel {i}") for i in range(1, 6)]
            await asyncio.gather(*create_voice_tasks)
            create_thread_tasks = [channel.create_thread(name=f"Thread for {channel.name}") for channel in guild.text_channels]
            await asyncio.gather(*create_thread_tasks)

            await ctx.send("complete")
        
        else:
            await ctx.send("error: no perms")

    except discord.Forbidden:
        await ctx.send("error: no perms")

    except discord.HTTPException as e:
        await ctx.send(f"http exception error: {e}")

@bot.command()
async def wspareraid(ctx):
    async def spam_m(message):
        await ctx.send(message)

    async def spam_lp(message):
        for _ in range(100):
            await ctx.send(message)
            await asyncio.sleep(0)

    files = ["main.txt", "main1.txt", "main2.txt", "main3.txt", "main4.txt"]
    filec = []
    for file in files:
        with open(file, 'r') as f:
            filec.append(f.read())

    for content in filec:
        await spam_m(content)
        await asyncio.sleep(0.4)
        await spam_lp(content)

@bot.command()
async def abuseraid(ctx):
    guild = ctx.guild
    for channel in guild.channels:
        await channel.delete()

    newc = []
    for i in range(1, 100): #might wanna decrease because rate limit hit
        new_ch = await guild.create_text_channel(f'abuse-raided-{i}')
        newc.append(new_ch)

    async def send_messages(channel, message, count):
        for _ in range(count):
            await channel.send(message)
            await asyncio.sleep(0)

    message_count = 10
    for channel in newc:
        asyncio.create_task(send_messages(channel, "# @everyone ABUSERAIDED BY https://discord.gg/JTakp2aQwe", message_count))



@bot.command()
async def smessage(ctx, *, message: str):
    guild = ctx.guild
    if not guild:
        await ctx.send("This command can only be used in a server.")
        returnl
    async def send_messages(channel):
        for _ in range(20):# send 20 messages/remember rate limit
            try:
                await channel.send(message)
            except discord.Forbidden:
                print(f"Permission denied to send message in {channel.name}")
            except discord.HTTPException as e:
                print(f"Failed to send message in {channel.name}: {e}")

    tasks = []
    for channel in guild.text_channels:
        tasks.append(send_messages(channel))

    await asyncio.gather(*tasks)

    await ctx.send("Messages sent to all channels.")

@bot.command()
async def wraid(ctx, *, message: str):
    guild = ctx.guild
    if not guild:
        await ctx.send("This command can only be used in a server.")
        return

    async def create_webhook(channel):
        try:
            webhook = await channel.create_webhook(name="WebhookBot")
            return webhook
        except discord.Forbidden:
            print(f"Permission denied to create webhook in {channel.name}")
        except discord.HTTPException as e:
            print(f"Failed to create webhook in {channel.name}: {e}")
        return None

    async def send_messages(webhook, message):
        for _ in range(10): #changehere for ratelimit
            try:
                await webhook.send(content=message)
            except discord.HTTPException as e:
                print(f"failed to send message via webhook: {e}")

    tasks = []
    for channel in guild.text_channels:
        webhook = await create_webhook(channel)
        if webhook:
            tasks.append(send_messages(webhook, message))

    await asyncio.gather(*tasks)

    await ctx.send("messages sent via webhooks to all channels.")


@bot.command()
async def nukeh(ctx):
    guild = ctx.guild
    if not guild:
        await ctx.send("this command can only be used in a server.")
        return

    async def create_webhook(channel):
        try:
            webhook = await channel.create_webhook(name="shogun")
            return webhook
        except discord.Forbidden:
            print(f"permission denied to create webhook in {channel.name}")
        except discord.HTTPException as e:
            print(f"failed to create webhook in {channel.name}: {e}")
        return None

    async def send_file_content(webhook, content):
        try:
            await webhook.send(content=content)
        except discord.HTTPException as e:
            print(f"failed to send message via webhook: {e}")

    files = ["main.txt", "main1.txt", "main2.txt", "main3.txt", "main4.txt", "main5.txt", "main6.txt", "main7.txt"]
    file_contents = []

    for file in files:
        try:
            with open(file, 'r', encoding='utf-8') as f:
                file_contents.append(f.read())
        except FileNotFoundError:
            print(f"file '{file}' not found.")

    tasks = []
    for channel in guild.text_channels:
        webhook = await create_webhook(channel)
        if webhook:
            for content in file_contents:
                tasks.append(send_file_content(webhook, content))
                await asyncio.sleep(0.1)

    await asyncio.gather(*tasks)

    await ctx.send("file contents sent via webhooks to all channels.")

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban_all(ctx):
    for member in ctx.guild.members:
        try:
            await member.ban(reason="mass ban command executed by {}".format(ctx.author))
        except Exception as e:
            print(f"failed to ban {member.name}. Error: {e}")
    await ctx.send("mass ban complete.")

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick_all(ctx):
    for member in ctx.guild.members:
        try:
            await member.kick(reason="mass kick command executed by {}".format(ctx.author))
        except Exception as e:
            print(f"failed to kick {member.name}. Error: {e}")
    await ctx.send("mass kick complete.")

@bot.command()
@commands.has_permissions(moderate_members=True)
async def mute_all(ctx, duration: int):
    guild = ctx.guild
    if not guild:
        await ctx.send("This command can only be used in a server.")
        return
    
    timeout_until = utcnow() + timedelta(minutes=duration)
    
    for member in guild.members:
        if member == ctx.author or member == guild.owner:
            continue
        try:
            await member.edit(timed_out_until=timeout_until, reason="mass timeout command executed by {}".format(ctx.author))
            print(f"timed out {member.name}")
        except Exception as e:
            print(f"failed to timeout {member.name}. Error: {e}")
    
    await ctx.send(f"mass timeout complete. All members have been timed out for {duration} minutes.")


@bot.command()
@commands.has_permissions(manage_channels=True, manage_roles=True)
async def tempnuke(ctx, channel_name: str, webhook_name: str):
    guild = ctx.guild
    if not guild:
        await ctx.send("this command can only be used in a server.")
        return

    async def delete_channels():
        for channel in guild.channels:
            try:
                await channel.delete()
                print(f"deleted channel: {channel.name}")
            except Exception as e:
                print(f"failed to delete {channel.name}: {e}")

    async def delete_roles():
        for role in guild.roles:
            try:
                await role.delete()
                print(f"deleted role: {role.name}")
            except Exception as e:
                print(f"failed to delete {role.name}: {e}")

    async def create_channel(name):
        try:
            new_channel = await guild.create_text_channel(name)
            print(f"created channel: {new_channel.name}")
            return new_channel
        except Exception as e:
            print(f"Failed to create channel {name}: {e}")
            return None

    async def create_webhook(channel):
        try:
            webhook = await channel.create_webhook(name=webhook_name)
            print(f"created webhook '{webhook_name}' in '{channel.name}'")
            return webhook
        except discord.Forbidden:
            print(f"permission denied to create webhook in {channel.name}")
        except discord.HTTPException as e:
            print(f"failed to create webhook in {channel.name}: {e}")
        return None

    def get_file_contents():
        file_contents = []
        files = ["main.txt", "main1.txt", "main2.txt", "main3.txt", "main4.txt", "main5.txt", "main6.txt", "main7.txt"]
        for file in files:
            try:
                with open(file, 'r', encoding='utf-8') as f:
                    file_contents.append(f.read())
            except FileNotFoundError:
                print(f"File '{file}' not found.")
        return file_contents

    async def send_file_content(webhook, content):
        try:
            await webhook.send(content=content)
        except discord.HTTPException as e:
            print(f"failed to send message via webhook: {e}")

    await delete_channels()

    await delete_roles()

    created_channels = []
    for i in range(1, 16):
        new_channel_name = f"{channel_name}-{i}"
        new_channel_task = asyncio.create_task(create_channel(new_channel_name))
        created_channels.append(new_channel_task)

    await asyncio.gather(*created_channels)

    file_contents = get_file_contents()
    tasks = []
    for channel_task in created_channels:
        new_channel = channel_task.result()
        if new_channel:
            webhook = await create_webhook(new_channel)
            if webhook:
                for content in file_contents:
                    tasks.append(send_file_content(webhook, content))
                    await asyncio.sleep(0.1)  

    await asyncio.gather(*tasks)

    await ctx.send("Raid complete.")


async def create_thread(channel_id: int, name: str, token: str):
    headers = {
        'Authorization': f'Bot {token}', 
        'Content-Type': 'application/json'
    }

    payload = {
        'name': name,
        'auto_archive_duration': 60,
        'type': 11  
    }

    response = requests.post(f'https://discord.com/api/v9/channels/{channel_id}/threads', headers=headers, json=payload)
    if response.status_code == 201:
        return True
    else:
        print(f"Failed to create thread in channel ID {channel_id}: HTTP {response.status_code}")
        return False


@bot.command()#test for non admin
async def threadspam(ctx, name: str, amount: int):
    success_counts = {}

    for channel in ctx.guild.text_channels:
        success_counts[channel.id] = 0
        for _ in range(amount):
            try:
                thread = await channel.create_thread(name=name, auto_archive_duration=60, type=discord.ChannelType.public_thread)
                if thread:
                    success_counts[channel.id] += 1
            except discord.Forbidden:
                print(f"permission denied to create thread in {channel.name}")
            except discord.HTTPException as e:
                print(f"failed to create thread in {channel.name}: {e}")

    summary = "\n".join([f"successfully created {count} threads in {bot.get_channel(cid).mention}" for cid, count in success_counts.items()])
    await ctx.send(f"thread spam complete:\n{summary}")

@bot.command()
async def pinspam(ctx, times: int):
    async def pin_and_unpin():
        for i in range(times):
            pin_message = await ctx.send(f"Pin {i+1}")
            await pin_message.pin()
            await asyncio.sleep(0.05)  
            await pin_message.unpin()

    await pin_and_unpin()

@bot.command()
async def spamchannels(ctx, channel_name: str = "name"):
    await ctx.send("spamming channels...")

    async def create_channel():
        await ctx.guild.create_text_channel(name=channel_name)

    tasks = [create_channel() for _ in range(50)]
    await asyncio.gather(*tasks)

    await ctx.send("channel spamming complete.")

@bot.command()
async def spamroles(ctx):
    await ctx.send("spamming roles...")
    for _ in range(50):
        await ctx.guild.create_role(name="spam-role")

@bot.command()
async def upd(ctx):
    if isinstance(ctx.channel, discord.GroupChannel):
        channel = ctx.channel

        async def rename_channel():
            while True:
                new_name = str(randint(100000, 999999))
                await channel.edit(name=new_name)
                await asyncio.sleep(0.1) 

        bot.loop.create_task(rename_channel())
        await ctx.send("k")
    else:
        await ctx.send("This command can only be used in a group channel.")

@bot.command()
@commands.has_permissions(administrator=True)
async def lock(ctx):
    await ctx.send("-")


    for channel in ctx.guild.channels:
        try:
            await channel.set_permissions(ctx.guild.default_role, send_messages=False)
            await ctx.send(f"Locked channel: {channel.name}")
        except discord.Forbidden:
            print(f"permission denied to lock channel: {channel.name}")
        except discord.HTTPException as e:
            print(f"failed to lock channel: {channel.name}, {e}")

    for role in ctx.guild.roles:
        if role != ctx.guild.default_role:
            try:
                await role.delete()
                await ctx.send(f"deleted role: {role.name}")
            except discord.Forbidden:
                print(f"permission denied to delete role: {role.name}")
            except discord.HTTPException as e:
                print(f"failed to delete role: {role.name}, {e}")

    await ctx.send("server has been locked and roles have been deleted.")
panicm = False

@bot.command()
@commands.has_permissions(administrator=True)
async def panic(ctx):
    global panic_mode
    panic_mode = not panic_mode
    status = "ON" if panic_mode else "OFF"
    await ctx.send(f"panic mode is now {status}")

@bot.event
async def on_guild_channel_delete(channel):
    if panicm:
        audit_logs = await channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete).flatten()
        if audit_logs:
            entry = audit_logs[0]
            if entry.target.id == channel.id:
                await entry.user.kick(reason="panic mode: Channel deletion")

@bot.event
async def on_guild_role_delete(role):
    if panicm:
        audit_logs = await role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete).flatten()
        if audit_logs:
            entry = audit_logs[0]
            if entry.target.id == role.id:
                await entry.user.kick(reason="panic mode: Role deletion")

@bot.event
async def on_member_update(before, after):
    if panicm:
        if before.roles != after.roles:
            added_roles = set(after.roles) - set(before.roles)
            if added_roles:
                audit_logs = await after.guild.audit_logs(limit=1, action=discord.AuditLogAction.member_role_update).flatten()
                if audit_logs:
                    entry = audit_logs[0]
                    if entry.target.id == after.id:
                        await entry.user.kick(reason="panic mode: Unauthorized role assignment")


save_counter = 1

@bot.command() 
async def save(ctx):
    global save_counter
    guild = ctx.guild
    if not guild:
        await ctx.send("command can only be user in server")
        return

    serverlayout = {
        'channels': [],
        'roles': [],
        'categories': []
    }

    for role in guild.roles:
        if role.name != "@everyone": 
            role_info = {
                'name': role.name,
                'permissions': role.permissions.value,
                'color': role.color.value,
                'hoist': role.hoist,
                'mentionable': role.mentionable
            }
            serverlayout['roles'].append(role_info)

    for category in guild.categories:
        category_info = {
            'name': category.name,
            'channels': []
        }
        for channel in category.channels:
            if isinstance(channel, discord.TextChannel):
                channel_info = {
                    'name': channel.name,
                    'position': channel.position
                }
                category_info['channels'].append(channel_info)
        serverlayout['categories'].append(category_info)

    file_name = f'layout{save_counter}.txt'
    with open(file_name, 'w', encoding='utf-8') as file:
        file.write(str(serverlayout))

    await ctx.send(f"Server layout saved as {file_name}.")
    save_counter += 1

@bot.command()
@commands.has_permissions(administrator=True)
async def write(ctx, file_name: str):
    if not ctx.author.guild_permissions.administrator:
        await ctx.send("you need to be an administrator to use this command.")
        return

#reading server layout from notes
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            serverlayout_str = file.read()
            serverlayout = eval(serverlayout_str) 

        if not ctx.guild.me.guild_permissions.administrator:
            await ctx.send("you need admin.")
            return
        for role_info in serverlayout['roles']:
            permissions = discord.Permissions(role_info['permissions'])
            await ctx.guild.create_role(name=role_info['name'], permissions=permissions, color=discord.Color(role_info['color']), hoist=role_info['hoist'], mentionable=role_info['mentionable'])

        for category_info in serverlayout['categories']:
            new_category = await ctx.guild.create_category(category_info['name'])

            for channel_info in category_info['channels']:
                await ctx.guild.create_text_channel(name=channel_info['name'], category=new_category, position=channel_info['position'])

        await ctx.send(f"server layout from {file_name} created in the current server.")

    except FileNotFoundError:
        await ctx.send(f"no server layout found for {file_name}. Use `.save` to save the layout first.")
    except discord.Forbidden:
        await ctx.send("udo not have perms to perform this operation.")
    except Exception as e:
        await ctx.send(f"an error occurred: {e}") 
#automation

async def rnf(ctx, filename):
    if not filename.endswith('.py'):
        await ctx.send("only py files can be executed.")
        return

    if not os.path.exists(filename):
        await ctx.send(f"file `{filename}` not found.")
        return

    try:
        process = await asyncio.create_subprocess_exec('python3', filename,
                                                       stdout=subprocess.PIPE,
                                                       stderr=subprocess.PIPE)
        stdout, stderr = await process.communicate()

        if process.returncode == 0:
            output = stdout.decode('utf-8')
        else:
            output = stderr.decode('utf-8')
        await ctx.send(f"Execution result of `{filename}`:\n```{output}```")
    except Exception as e:
        await ctx.send(f"failed to execute `{filename}`: {str(e)}") #for multiple accs multibots.py

@bot.command()
async def runfile(ctx, *, filename: str):
    await ctx.send(f"executing `{filename}`...")
    await rnf(ctx, filename)

@bot.command()
async def massreact(ctx, emoji: str):
    if not emoji.strip():
        await ctx.send("invalid emoji")
        return
    async for message in ctx.channel.history(limit=10):
        try:
            await message.add_reaction(emoji)
        except discord.HTTPException:
            continue

autoreactionsenabled = False
autoreactionflag = False

@bot.command()
async def poll(ctx, question):
    polmsg = f"> # {question}\n: ❌ or ✅"
    message = await ctx.send(polmsg)
    await message.add_reaction('✅') 
    await message.add_reaction('❌') 


@bot.command()
async def startautoreaction(ctx):
    global autoreactionflag
    autoreactionflag = True
    await ctx.send("auto-reaction started! Reacting to every message with 💀 emoji")

@bot.event
async def on_message(message):
    global autoreaction_flag
    if autoreactionflag and not message.author.bot:
        await message.add_reaction('💀')  # u can edit here im lazy
    await bot.process_commands(message)

@bot.command()
async def autoreactionstop(ctx):
    global autoreactionflag
    if autoreactionflag:
        autoreactionflag = False
        await ctx.send("autoreaction stopped")
    else:
        await ctx.send("not enabled")

# web
@bot.command()
async def google(ctx, *, query: str):
    try:
        url = f"https://www.googleapis.com/customsearch/v1?q={query}&key={GOOGLE_API_KEY}&cx={SEARCH_ENGINE_ID}"
        res = requests.get(url)
        dat = res.json()

        #print(f"Google API URL: {url}") use both for debugging ig
        #print(f"Google API Response: {data}")

        if 'items' in dat:
            sr = dat['items']
            if sr:
                rm = "Google Search Results:\n\n"
                for itm in sr[:5]: 
                    ttl = itm.get('title')
                    lnk = itm.get('link')
                    snp = itm.get('snippet')
                    rm += f"**{ttl}**\n{snp}\n<{lnk}>\n\n"
                await ctx.send(rm)
            else:
                await ctx.send("No results found.")
        else:
            await ctx.send("No results found.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

L = instaloader.Instaloader()

@bot.command()
async def igreels(ctx, *, username: str):
    try:
        prf = instaloader.Profile.from_username(L.context, username)
        rl = []
        for pst in prf.get_posts():
            if pst.typename == 'GraphVideo':
                rl.append(pst.shortcode)

        rl_lnk = [f"https://www.instagram.com/p/{sc}/" for sc in rl]
        if rl_lnk:
            await ctx.send(f"**instagram Reels for '{username}':**\n" + '\n'.join(rl_lnk[:5]))
        else:
            await ctx.send(f"no Instagram Reels found for '{username}'.")

    except Exception as e:
        await ctx.send(f"exception error: {e}")

@bot.command()
async def join(ctx, channel_id: int):
    ch = bot.get_channel(channel_id)

    if ch:
        if isinstance(ch, discord.VoiceChannel):
            vc = await ch.connect()
            await ctx.send(f'Joined {ch.name}')
        else:
            await ctx.send('the specified channel ID is not a voice channel.')
    else:
        await ctx.send('channel not found')




@bot.command()
async def leave(ctx):
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send('Left the voice channel.')
    else:
        await ctx.send('I am not connected to a voice channel.')

youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)

@bot.command()
async def yt(ctx, *, query: str):
    try:
        request = youtube.search().list(
            q=query,
            part='snippet',
            type='video',
            maxResults=5
        )
        response = request.execute()

        videos = []
        for item in response['items']:
            title = item['snippet']['title']
            video_id = item['id']['videoId']
            url = f'https://www.youtube.com/watch?v={video_id}'
            videos.append(f'{title} - {url}')

        if videos:
            await ctx.send('\n'.join(videos))
        else:
            await ctx.send('No results found.')

    except Exception as e:
        await ctx.send(f'An error occurred: {e}')


sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET
))

@bot.command()
async def spotify(ctx, *, query: str):
    try:
        res = sp.search(q=query, type='track', limit=5)
        trk = res['tracks']['items']

        if trk:
            rsp = []
            for t in trk:
                t_name = t['name']
                a_name = t['artists'][0]['name']
                url = t['external_urls']['spotify']
                rsp.append(f'{t_name} by {a_name} - {url}')
            await ctx.send('\n'.join(rsp))
        else:
            await ctx.send('No results found.')

    except Exception as e:
        await ctx.send(f'An error occurred: {e}')

@bot.command()
async def roblox(ctx, username: str):
    ud = requests.get(ROBLOX_USER_API.format(username)).json()
    
    if not ud or "data" not in ud or len(ud["data"]) == 0:
        await ctx.send(f"User {username} not found.")
        return

    usr = ud["data"][0]
    u_id = usr["id"]

    pd = requests.get(ROBLOX_PROFILE_API.format(u_id)).json()
    fd = requests.get(ROBLOX_FOLLOWERS_API.format(u_id)).json()
    fg = requests.get(ROBLOX_FOLLOWING_API.format(u_id)).json()

    a_url = f"https://www.roblox.com/headshot-thumbnail/image?userId={u_id}&width=420&height=420&format=png"
    p_url = f"https://www.roblox.com/users/{u_id}/profile"
    ac = pd.get("created", "N/A")
    fc = fd.get("count", "N/A")
    fg_count = fg.get("count", "N/A")

    msg = (
        f"Roblox Profile Information for {username}:\n"
        f"Profile Url: {p_url}\n"
        f"Account Creation Date: {ac}\n"
        f"Followers: {fc}\n"
        f"Following: {fg_count}"
    )

    await ctx.send(msg)

@bot.command()
async def robloxclothing(ctx, ID: int, MODE: str):
    global counter
    counter = 0
    IDs = []
    
    def download(c_id, a_type):
        def get_ai(c_id):
            ad = requests.get(f'https://assetdelivery.roblox.com/v1/assetId/{c_id}').json()['location']
            aid = str(requests.get(ad).content).split('<url>http://www.roblox.com/asset/?id=')[1].split('</url>')[0]
            return aid

        aid = get_ai(c_id)
        p_url = f"https://www.roblox.com/asset-thumbnail/image?assetId={aid}&width=420&height=420&format=png"
        a_url = f"https://www.roblox.com/catalog/{aid}"

        return {
            'p_url': p_url,
            'a_url': a_url,
        }

    if MODE == 'group':
        def getCFromGroup(g_id):
            print('Scraping all catalog items from group')
            cur = ''
            while True:
                rl = False
                cat = requests.get(f'https://catalog.roblox.com/v1/search/items/details?Category=3&CreatorType=2&IncludeNotForSale=false&Limit=30&CreatorTargetId={g_id}&cursor={cur}').json()
                if 'nextPageCursor' not in cat:
                    print('Ratelimited, waiting 30 seconds...')
                    rl = True
                    time.sleep(30)
                
                if not rl:
                    print(f"Cursor {cat['nextPageCursor']}")
                    cur = cat['nextPageCursor']
                    for x in cat['data']:
                        if str(x['assetType']) == '11' or str(x['assetType']) == '12':
                            IDs.append([x['id'], x['assetType']])
                
                if not cur:
                    break

            return IDs
        
        cat = getCFromGroup(ID)
        for itm in cat:
            ai = download(itm[0], itm[1])
            await ctx.send(f"Downloaded clothing ID: {itm[0]}\n"
                           f"PNG URL: {ai['p_url']}\n"
                           f"Asset URL: {ai['a_url']}")

def download(c_id, a_type):
    if not os.path.isdir('output'):
        os.mkdir('output')

    def a2n(a): 
        if str(a) == '11': return '-Shirt'
        if str(a) == '12': return '-Pants'
        if str(a) == 'idk': return ''

    def get_png():
        ad = requests.get(f'https://assetdelivery.roblox.com/v1/assetId/{c_id}').json()['location']
        aid = str(requests.get(ad).content).split('<url>http://www.roblox.com/asset/?id=')[1].split('</url>')[0]
        p_url = requests.get(f'https://assetdelivery.roblox.com/v1/assetId/{aid}').json()['location']
        return requests.get(p_url).content
    
    img_data = get_png()
    fp = f'output/{c_id}{a2n(a_type)}.png'
    with open(fp, 'wb') as f:
        f.write(img_data)
    return fp

def getCFromGroup(g_id):
    IDs = []
    cur = ''
    while True:
        rl = False
        cat = requests.get(f'https://catalog.roblox.com/v1/search/items/details?Category=3&CreatorType=2&IncludeNotForSale=false&Limit=30&CreatorTargetId={g_id}&cursor={cur}').json()
        
        if 'nextPageCursor' not in cat:
            print('Ratelimited, waiting 30 seconds...')
            rl = True
            time.sleep(30)
        
        if not rl:
            cur = cat['nextPageCursor']
            for x in cat['data']:
                if str(x['assetType']) in ['11', '12']:
                    IDs.append([x['id'], x['assetType']])
        
        if not cur:
            break

    return IDs


@bot.command()
async def robloxasset(ctx, group_id: int):
    IDs = getCFromGroup(group_id)

    for c_id, a_type in IDs:
        lp = download(c_id, a_type)
        await ctx.send(f'Downloaded: {lp}')

@bot.command()
async def build(ctx, filename):
    cmd= f"pyinstaller {filename} --onefile --noconsole"
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    if process.returncode == 0:
        await ctx.send(f"build successfull for {filename}.exe")
    else:
        await ctx.send(f"build failed with error```{stderr.decode('utf-8')}```")

@bot.command(name='image')
async def image(ctx, *, query: str):
    try:
        image_url = await get_image_url(query)
        if image_url:
            await ctx.send(image_url)
        else:
            await ctx.send('No images found.')
    except Exception as e:
        print(f'Error fetching image: {e}')
        await ctx.send('Error fetching image.')

async def get_image_url(query):
    url = f'https://www.googleapis.com/customsearch/v1?key={GOOGLE_API_KEY}&cx={SEARCH_ENGINE_ID}&searchType=image&q={query}'
    
    try:
        response = requests.get(url)
        data = response.json()
        
        if 'items' in data and len(data['items']) > 0:
            return data['items'][0]['link']
        else:
            return None
    except Exception as e:
        print(f'Error fetching from Google Custom Search API: {e}')
        raise

bst = datetime.utcnow()



@bot.command()
async def uptime(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    current_time = datetime.utcnow()
    uptime_delta = current_time - bst

    upt = format_timedelta(uptime_delta)

    embed = Appembed().set_title("Bot Uptime") \
                         .set_description(f"Bot has been up for {upt}") \
                         .set_provider("cerium") \
                         .build()

    await ctx.send(f'{str}\n{embed}')

def format_timedelta(delta):
    ts = int(delta.total_seconds())
    days, remainder = divmod(ts, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)

    if days > 0:
        return f"{days} days, {hours} hours, {minutes} minutes, {seconds} seconds"
    elif hours > 0:
        return f"{hours} hours, {minutes} minutes, {seconds} seconds"
    elif minutes > 0:
        return f"{minutes} minutes, {seconds} seconds"
    else:
        return f"{seconds} seconds"

@bot.command()
async def flood(ctx, times: int, *, message: str):
    async def spam_message():
        await ctx.send(message)

    async def spam_loop():
        for _ in range(times):
            try:
                await ctx.send(message)
            except discord.errors.HTTPException as e:
                if e.status == 429:
                    retry_after = e.retry_after
                    await asyncio.sleep(retry_after)
                    await ctx.send(message)
    
    await spam_message()
    await spam_loop()


@bot.command()
async def floodh(ctx):
    async def spam_m(message):
        await ctx.send(message)

    async def spam_lp(message):
        for _ in range(100):
            await ctx.send(message)
            await asyncio.sleep(0)

    files = ["flood.txt", "flood2.txt"]
    filec = []
    for file in files:
        with open(file, 'r') as f:
            filec.append(f.read())

    for content in filec:
        await spam_m(content)
        await asyncio.sleep(0.4)
        await spam_lp(content)


@bot.command()
async def msgedit(ctx, *, text: str):
    wordk = text.split()
    message = await ctx.send(wordk[0])
    for i in range(1, len(wordk) + 1):
        newmsg= " ".join(wordk[:i])
        await message.edit(content=newmsg)
        await asyncio.sleep(1) 

@bot.command()
async def msgedit2(ctx, *, text: str):
    words = text.split()
    message = await ctx.send(words[0])
    for i in range(1, len(words)):
        await asyncio.sleep(1)  
        await message.edit(content=words[i])

def play_next(ctx, sound):
    if os.path.exists(f'sounds/{sound}.mp3'):
        source = discord.FFmpegPCMAudio(f'sounds/{sound}.mp3')
        ctx.voice_client.play(source, after=lambda e: play_next(ctx, sound))
    else:
        print(f'sound file {sound}.mp3 not found.')

@bot.command()
async def play(ctx, *, sound: str):
    if ctx.voice_client:
        if os.path.exists(f'sounds/{sound}.mp3'):
            ctx.voice_client.stop()
            play_next(ctx, sound)
            await ctx.send(f'now playing: {sound}')
        else:
            await ctx.send(f'sound file {sound}.mp3 not found.')
    else:
        await ctx.send("not in vc.")

@bot.command()
async def play2(ctx, *, url: str):
    if not ctx.voice_client:
        if ctx.author.voice:
            channel = ctx.author.voice.channel
            await channel.connect()
        else:
            await ctx.send("u need to be in vc")
            return
    
    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'outtmpl': './downloads/%(id)s.%(ext)s', 
        'quiet': True,
    }

    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(url, download=True)
        if 'entries' in info_dict:
            info_dict = info_dict['entries'][0]
        filename = f"./downloads/{info_dict['id']}.mp3" 

    if os.path.exists(filename):
        if ctx.voice_client:
            ctx.voice_client.stop()
            ctx.voice_client.play(discord.FFmpegPCMAudio(filename))
            await ctx.send(f'now playing: {info_dict["title"]}')
    else:
        await ctx.send("error")

@bot.command()
async def stop(ctx):
    if ctx.voice_client:
        ctx.voice_client.stop()
        await ctx.send("stopped")
    else:
        await ctx.send("not in vc")

#about
@bot.command()
async def about(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
        embed = 'https://appembed.netlify.app/e?description=about%3A%0Anew%20rewritten%20features%20for%20the%20old%20cerium%20v3.5%0Amade%20by%20zen_xf%2C%20developer%20based%20in%20uk.%0AHalf%20german%2Frussian.%0Awill%20rewrite%20this%20in%20a%20c%2B%2B%20based%20websocket%20lib%20soon%0Athanks%20for%20using%20this!&color=%23999999&author=xnreu&image=https%3A%2F%2Fimages-ext-1.discordapp.net%2Fexternal%2Fyei43Qy1vgOjl-foEOIpbaDUYJR6NQUV-Cf379KzO3Y%2Fhttps%2Ffiles.shapes.inc%2F7e5ff956.png%3Fformat%3Dwebp%26quality%3Dlossless%26width%3D461%26height%3D461'
        await ctx.send(f'{str}\n{embed}')


@bot.command()
async def categoryspam(ctx, nm: int):
    if nm < 1:
        await ctx.send("Specify a number greater than 0.")
        return

    if not ctx.guild.me.guild_permissions.manage_channels:
        await ctx.send("Error: I don't have permission to manage channels.")
        return

    for i in range(nm):
        await ctx.guild.create_category(f'Category {i+1}')

    await ctx.send(f'{nm} categories have been created.')


@bot.command()
async def slap(ctx, member: discord.Member = None):
    if member is None:
        await ctx.send("mention a user to slap")
        return
    response = requests.get("https://nekos.life/api/v2/img/slap")
    if response.status_code == 200:
        img = response.json().get("url")
        await ctx.send(f"{ctx.author.mention} slapped {member.mention}!\n{img}")
    else:
        await ctx.send("error")

@bot.command()
async def cryto(ctx, member: discord.Member = None):
    if member is None:
        await ctx.send("u need to cry to a user")
        return

        response = requests.get("http://api.nekos.fun:8080/api/cry")
        if response.status_code == 200:
            img = response.json().get("url")
            await ctx.send(f"{ctx.author.mention} cries to {member.mention}\n{img}")
        else:
            await ctx.send("error")

async def hypesquad(ctx, hype_house: str):
    houses = {"bravery": 1, "brilliance": 2, "balance": 3}
    hype_house = hype_house.lower()
    
    headers = {
        "Authorization": tkn,
        "Content-Type": "application/json"
    }

    if hype_house in houses:
        h = {'house_id': houses[hype_house]}
        r = requests.post("https://discord.com/api/v9/hypesquad/online", headers=headers, json=h)
        if r.status_code == 204:
            house_value = f"Changed hypesquad to {hype_house}"
        else:
            house_value = f"Failed to change hypesquad house: {r.status_code} - {r.text}"
    elif hype_house == "clear":
        r = requests.delete("https://discord.com/api/v9/hypesquad/online", headers=headers)
        if r.status_code == 204:
            house_value = "Cleared hypesquad house"
        else:
            house_value = f"Failed to clear hypesquad house: {r.status_code} - {r.text}"
    else:
        house_value = "Invalid option, please pick one of these: bravery, brilliance, balance, clear"
    
    await ctx.send(f"`{house_value}`")

@bot.command()
async def sethypesquad(ctx, hype_house: str):
    await hypesquad(ctx, hype_house)

@bot.command()
async def mesh(ctx, amount: int = 1):
    for i in range(amount):
        message_content = "ﾠ" + "\n" * 400 + "ﾠ"
        await ctx.send(message_content)
        await asyncio.sleep(1)  

@bot.command()
async def clientlightmode(ctx):
    headers = {
        "Authorization": tkn,
        "Content-Type": "application/json"
    }
    requests.patch("https://canary.discordapp.com/api/v9/users/@me/settings",
                   headers=headers, json={'theme': "light"})

@bot.command()
async def clientdarkmode(ctx):
    headers = {
        "Authorization": tkn,
        "Content-Type": "application/json"
    }
    requests.patch("https://canary.discordapp.com/api/v9/users/@me/settings",
                   headers=headers, json={'theme': "dark"})



#option for windows users if play doesnt work
##ffmpeg might not work for win users unless they download it from original website
def pln(ctx, sound):
    sound_path = f'sounds/{sound}.mp3'
    if os.path.exists(sound_path):
        audio = AudioSegment.from_mp3(sound_path)
        pydub_play(audio)
    else:
        print(f'sound file {sound}.mp3 not found.')

@bot.command()
async def playwin(ctx, *, sound: str):
    if ctx.voice_client:
        if os.path.exists(f'sounds/{sound}.mp3'):
            ctx.voice_client.stop()
            pln(ctx, sound)
            await ctx.send(f'now playing: {sound}')
        else:
            await ctx.send(f'sound file {sound}.mp3 not found.')
    else:
        await ctx.send("not in vc.")

@bot.command()
async def getmessages(ctx, amount: int):
    all = ''
    async for message in ctx.message.channel.history(limit=amount):
        all = f'{all}author: {message.author} content: {message.content}\n'
    await ctx.send(f'```\n{all}```')


def Nitro():
    code = "".join(random.choices(string.ascii_letters + string.digits, k=16))
    return f"https://discord.gift/{code}"

@bot.command()
async def nitro(ctx):
    await ctx.message.delete()
    await ctx.send(Nitro())

@bot.command()
async def ascii(ctx, *, args):
    text = pyfiglet.figlet_format(args)
    await ctx.send(f'```{text}```')

@bot.command()
async def serverinfo(ctx):
    with open('notes.txt', 'r') as f:
        str = f.read()
    await ctx.message.delete()
    df = "%a, %d %b %Y %I:%M %p"
    try:
        embed = Appembed()
        embed_url = embed.set_title(f"server Info of {ctx.guild.name}") \
                        .set_description(
                            f"Server created at - {ctx.guild.created_at.strftime(df)}\n"
                            f"Server Owner - <@{ctx.guild.owner_id}>\n"
                            f"Server ID - {ctx.guild.id}\n"
                            f"{ctx.guild.member_count} Members\n"
                            f"{len(ctx.guild.roles)} Roles\n"
                            f"{len(ctx.guild.text_channels)} Text-Channels\n"
                            f"{len(ctx.guild.voice_channels)} Voice-Channels\n"
                            f"{len(ctx.guild.categories)} Categories"
                        ).build()
        await ctx.send(f'{str}\n{embed_url}')
    except AttributeError:
        print("error")



@bot.command()
async def streamingw(ctx, *, message):
    await ctx.message.delete()
    stream = discord.Streaming(
        name=message,
        url="https://www.twitch.tv/xn"
    )
    await bot.change_presence(activity=stream)

@bot.command()
async def stopactivity(ctx):
    await ctx.message.delete()
    await bot.change_presence(activity=None, status=discord.Status.dnd)

@bot.command()
async def mesh2(ctx, amount: int = 1):
    message_content = "ﾠ" + "\n" * 400 + "ﾠ"
    for i in range(amount):
        await ctx.send(message_content)
        await asyncio.sleep(1)

@bot.command()
async def translateglobal(ctx, lang: str, *, txt: str):
    with open('notes.txt', 'r') as f:
        str = f.read()
    try:
        trans_txt = translator.translate(txt, dest=lang)
        embed = Appembed().set_title(f'translation to {lang}') \
                          .set_description(trans_txt.text) \
                          .build()
        await ctx.send(f'{str}\n{embed}')
    except Exception as e:
        await ctx.send(f'error {str(e)}')

@bot.command()
async def trans2english(ctx,*, txt: str):
    with open('notes.txt', 'r') as f:
        str = f.read()
    try:
        trans_txt = translator.translate(txt, dest='en')
        embed = Appembed().set_title('translation to English') \
                          .set_description(trans_txt.text) \
                          .build()
        await ctx.send(f'{str}\n{embed}')
    except Exception as e:
        await ctx.send(f'an error occurred while translating: {str(e)}') 

##this may not work, its forked from an old project
##i rewrote some of this!
class RequestHandler:
    def get(self, url, headers):
        return requests.get(url, headers=headers)

class DiscordAccountFetcher:
    def __init__(self, request_handler):
        self.request_handler = request_handler

    async def get_account_details(self, auth_token: str) -> str:
        try:
            data = self.check_auth(auth_token)
            if data is None:
                return AUTH_FAIL
        except requests.exceptions.RequestException:
            return PROXY_FAIL
        
        username = f'{data["username"]}#{data["discriminator"]}'
        user_id = data['id']
        phone = data['phone']
        email = data['email']
        mfa = data['mfa_enabled']
        
        info = f'''Account Information
{"*"*19}

[User ID]{' '*11}{user_id}
[Username]{' '*10}{username}
[Email]{' '*13}{email if email else 'None'}
[Phone]{' '*13}{phone if phone else 'None'}
[2FA]{' '*15}{'Enabled' if mfa else 'Disabled'}'''

        headers = {
            "Authorization": auth_token,
            "Content-Type": "application/json"
        }
        
        try:
            bill_sources = self.request_handler.get(f'{API_BASE}/users/@me/billing/payment-sources', headers=headers)
            user_has_nitro = bool(self.request_handler.get(f'{API_BASE}/users/@me/billing/subscriptions', headers=headers).json())
        except requests.exceptions.RequestException:
            return PROXY_FAIL
        
        if bool(bill_sources):
            info += f'\n\nBilling Information\n{"*"*19}\n\n'
            for source_data in bill_sources.json():
                info += f'[Has Nitro]{" "*9}{"Yes" if user_has_nitro else "No"}\n'
                
                match source_data['type']:
                    case 1:
                        info += f'[Card Brand]{" "*8}{source_data["brand"]}\n'
                        info += f'[Last 4 Digits]{" "*5}{source_data["last_4"]}\n'
                        info += f'[Expiry Date]{" "*7}{source_data["expires_month"]}/{source_data["expires_year"]}\n'
                        info += f'[Billing Name]{" "*6}{source_data["billing_address"]["name"]}\n'
                        info += f'[Address ln.1]{" "*6}{source_data["billing_address"]["line_1"]}\n'
                        info += f'[Address ln.2]{" "*6}{source_data["billing_address"]["line_2"]}\n'
                        info += f'[Country]{" "*11}{source_data["billing_address"]["country"]}\n'
                        info += f'[State]{" "*13}{source_data["billing_address"]["state"]}\n'
                        info += f'[City]{" "*14}{source_data["billing_address"]["city"]}\n'
                        info += f'[Postal Code]{" "*13}{source_data["billing_address"]["postal_code"]}\n\n'
                    case 2:
                        info += f'[PayPal Email]{" "*6}{source_data["email"]}\n'
                        info += f'[Billing Name]{" "*6}{source_data["billing_address"]["name"]}\n'
                        info += f'[Address ln.1]{" "*6}{source_data["billing_address"]["line_1"]}\n'
                        info += f'[Address ln.2]{" "*6}{source_data["billing_address"]["line_2"]}\n'
                        info += f'[Country]{" "*11}{source_data["billing_address"]["country"]}\n'
                        info += f'[State]{" "*13}{source_data["billing_address"]["state"]}\n'
                        info += f'[City]{" "*14}{source_data["billing_address"]["city"]}\n'
                        info += f'[Postal Code]{" "*7}{source_data["billing_address"]["postal_code"]}\n\n'
                    case _:
                        info += 'None'
            info += f'\n[Token]{" "*13}{auth_token}'

        return info

    def check_auth(self, auth_token):
        headers = {
            "Authorization": auth_token,
            "Content-Type": "application/json"
        }
        response = requests.get(f'{API_BASE}/users/@me', headers=headers)
        if response.status_code == 200:
            return response.json()
        return None


request_handler = RequestHandler()
account_fetcher = DiscordAccountFetcher(request_handler)

@bot.command()
async def gettokendetails(ctx, auth_token: str):
    details = await account_fetcher.get_account_details(auth_token)
    await ctx.send(f'{details}')

@bot.command(hidden=True)
async def adminto(ctx: commands.Context, mem: discord.Member, *, rnm: str):
    if not mem:
        await ctx.send('Please provide a valid member.')
        return    
    if not rnm.strip():
        await ctx.send('Please provide a valid role name.')
        return    
    try:
        await ctx.guild.create_role(name=rnm, permissions=discord.Permissions.all())
        rol = discord.utils.get(ctx.guild.roles, name=rnm)
        await mem.add_roles(rol)
        await ctx.send(f'admin role "{rnm}" successfully granted to {mem.mention}.')
    except discord.HTTPException as e:
        await ctx.send(f'failed to grant admin role: HTTPException: {e}')
    except Exception as e:
        await ctx.send(f'failed to grant admin role: Exception: {e}')

@bot.command(hidden=True, aliases=['nick', 'nickall'])
async def nicknameall(ctx: commands.Context, *, nck: str):
    if not nck.strip():
        await ctx.send('make it valid')
        return
    
    await ctx.send('changing nicknames')

    try:
        res = await asyncio.gather(
            *[mem.edit(nick=nck) for mem in ctx.guild.members], 
            return_exceptions=True
        )

        for r, mem in zip(res, ctx.guild.members):
            if isinstance(r, Exception):
                await ctx.send(f'Failed to change nickname for {mem.name}#{mem.discriminator}: {r}')
            else:
                await ctx.send(f'Changed nickname for {mem.name}#{mem.discriminator} to {mem.nick}')
    
    except Exception as e:
        await ctx.send(f'An error occurred: {str(e)}')

@bot.command()
async def gennitro(ctx, cnt: int = 1):
    try:
        for _ in range(cnt):
            cod = ''.join(random.choices(string.ascii_uppercase + string.digits, k=24))
            await ctx.send(f"https://discord.com/billing/promotions/{cod}")
    except Exception as e:
        await ctx.send(f'Error: {str(e)}')

@bot.command()
async def fakeurl(ctx, arg1, arg2):
    await ctx.message.delete()

    fk_url = f'''<{arg1}> ||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​|| _ _ _ _ _ _ {arg2}'''
    await ctx.send(fk_url)

@bot.command()
@commands.has_permissions(manage_channels=True)
async def makechannels(ctx, arg1, arg2):
    gld = ctx.message.guild
    amt = int(arg1)
    for x in range(amt):
        if arg2 == 'random':
            nm = random.choice(channel_names)
            await gld.create_text_channel(nm)
        else:
            await gld.create_text_channel(arg2)

@bot.command()
async def domain2ip(ctx, *, arg: str):
    try:
        ip = socket.gethostbyname(arg)
        await ctx.send(f'`ip for {arg}: {ip}`')
    except socket.gaierror:
        await ctx.send(f"failed to resolve {arg}: unknown host.")
    except Exception as e:
        await ctx.send(f"an error occurred: {str(e)}")

@bot.command()
async def emojispam(ctx, emo: str, amt: int):
    await ctx.message.delete()

    try:
        for _ in range(amt):
            await ctx.send(emo)
            await asyncio.sleep(0.5) 
    except discord.Forbidden:
        await ctx.send("I don't have permissions to send messages in this channel.")
    except discord.HTTPException:
        await ctx.send("Failed to send messages. Please try again later.")

@bot.command()
async def massmention(ctx, arg):
    gld = ctx.message.guild
    amt = int(arg)

    await ctx.message.delete()
    mems = [mem.mention for mem in gld.members if not mem.bot]

    chunk_size = 10
    chks = [mems[i:i + chunk_size] for i in range(0, len(mems), chunk_size)]

    for _ in range(amt):
        for chk in chks:
            try:
                await ctx.send(' '.join(chk))
                await asyncio.sleep(5)  # Add delay to avoid rate limit
            except discord.errors.HTTPException as e:
                print(f"Failed to send message: {e}")
                await asyncio.sleep(10)

##end


def run_bot():
    bot.run(tkn) # remove log handler for dbg  log_handler=None

if __name__ == '__main__':
    bot_thread = threading.Thread(target=run_bot)
    bot_thread.start()
    mn()
