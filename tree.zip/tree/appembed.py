# EXAMPLE USAGE
# =============

# app = Appembed()
# embed_url = app.set_title("Wassup!") \
#               .set_provider("Hey!") \
#               .build()
# print(embed_url)

import urllib.parse

class Appembed:
    def __init__(self):
        self.url = ''

    def encode(self, text):
        return urllib.parse.quote(text)

    def set_title(self, text):
        self.url += "&t=" + self.encode(text)
        return self

    def set_description(self, text):
        self.url += "&d=" + self.encode(text)
        return self

    def set_color(self, text):
        self.url += "&c=" + self.encode(text)
        return self

    def set_redirect(self, text):
        self.url += "&r=" + self.encode(text)
        return self

    def set_author(self, text):
        self.url += "&a=" + self.encode(text)
        return self

    def set_author_url(self, text):
        self.url += "&au=" + self.encode(text)
        return self

    def set_image(self, text):
        self.url += "&i=" + self.encode(text)
        return self

    def set_provider(self, text):
        self.url += "&p=" + self.encode(text)
        return self

    def set_provider_url(self, text):
        self.url += "&pu=" + self.encode(text)
        return self

    def set_url(self, text):
        self.url += "&u=" + self.encode(text)
        return self

    def set_youtube(self, text):
        self.url += "&yt=" + self.encode(text)
        return self

    def set_oembed(self, text):
        self.url += "&oembed=" + self.encode(text)
        return self

    def build(self):
        return 'https://appembed.netlify.app/e?' + self.url[1:]
